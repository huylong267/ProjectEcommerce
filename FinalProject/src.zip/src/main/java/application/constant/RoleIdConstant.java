package application.constant;

public class RoleIdConstant {
    public static final int Role_Admin =1;
    public static final int Role_User =2;
}
