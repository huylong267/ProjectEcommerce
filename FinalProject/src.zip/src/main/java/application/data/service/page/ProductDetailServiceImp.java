package application.data.service.page;

import application.data.model.ProductDetail;
import application.data.repository.web.iProductDetailRepository;
import application.data.repository.web.iProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductDetailServiceImp implements iProductDetailService {
    @Autowired
    private iProductDetailRepository iProductDetailRepository;

    @Override
    public ProductDetail findOne(int productdetailid) {
        return iProductDetailRepository.findOne(productdetailid);
    }

    @Override
    public void createDetail(ProductDetail productDetail) {
        iProductDetailRepository.save(productDetail);
    }
}
