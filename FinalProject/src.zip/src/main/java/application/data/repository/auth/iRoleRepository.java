package application.data.repository.auth;

import application.data.model.Role;
import org.springframework.data.repository.CrudRepository;

public interface iRoleRepository extends CrudRepository<Role,Integer>{

    Role findByName(String name);

}
