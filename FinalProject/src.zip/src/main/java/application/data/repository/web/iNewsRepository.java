package application.data.repository.web;

import application.data.model.News;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;


public interface iNewsRepository extends CrudRepository<News,Integer> {

}
