package application.data.service.page;

import application.data.model.Product;
import application.data.repository.web.iProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImp implements iProductService {
    @Autowired
    private iProductRepository iProductRepository;
    @Override
    public void addNewProduct(Product product) {
        iProductRepository.save(product);
    }

    @Override
    public Product findOneProduct(int productId) {
        return iProductRepository.findOne(productId);
    }

    @Override
    public List<Product> findAllProduct() {
        return iProductRepository.findAll();
    }

    @Override
    public void updateproduct(Product product) {
        iProductRepository.save(product);
    }
}
