package application.constant;

public class Constant {
    public final static String PREFIX_LINK_UPLOAD = "/link/";
	public  static  final  String UPLOAD_FOLDER="src\\main\\resources\\static\\upload";

}
