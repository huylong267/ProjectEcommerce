package application.constant;

public class StatusRoleConstant {
    public static final int ActiveStatus =1;
    public static final int NonActiveStatus =2;
}
