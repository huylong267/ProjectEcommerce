package application.data.repository.web;

import application.data.model.ProductDetail;
import application.model.ProductDataModel;
import org.springframework.data.repository.CrudRepository;

public interface iProductDetailRepository extends CrudRepository<ProductDetail,Integer> {
}
