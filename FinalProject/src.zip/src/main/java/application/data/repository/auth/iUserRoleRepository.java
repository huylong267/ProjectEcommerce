//package application.data.repository.auth;
//
//
//import application.data.model.UserRole;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.data.repository.query.Param;
//import org.springframework.transaction.annotation.Transactional;
//
//public interface iUserRoleRepository extends CrudRepository<UserRole,Integer> {
//
//    @Transactional(readOnly=true)
//    @Query("select u from tbl_user_role u where u.user_id = :user_id")
//    Iterable<UserRole> findRoleOfUser(@Param("user_id") int userId);
//
//}
