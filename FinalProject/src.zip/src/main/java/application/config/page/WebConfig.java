package application.config.page;

import application.data.service.auth.UserService;
import application.data.service.page.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.thymeleaf.ThymeleafProperties;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.thymeleaf.templateresolver.FileTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

@Configuration
public class WebConfig  extends WebMvcConfigurerAdapter{

    @SuppressWarnings("SpringJavaAutowiringInspection")
    @Autowired
    private ThymeleafProperties properties;

    @Value("${spring.thymeleaf.templates_root:}")
    private String templatesRoot;

    @Bean
    public ITemplateResolver defaultTemplateResolver(){
        FileTemplateResolver resolver = new FileTemplateResolver();
        resolver.setSuffix(properties.getSuffix());
        resolver.setPrefix(templatesRoot);
        resolver.setTemplateMode(properties.getMode());
        resolver.setCacheable(properties.isCache());
        return  resolver;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/webjars/**",
                "/static/img/**",
                "/static/css/**",
                "/static/js/**",
        "/static/upload/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/",
                        "classpath:/static/img/",
                        "classpath:/static/css/",
                        "classpath:/static/js",
                        "classpath:/static/upload");
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource bean = new ReloadableResourceBundleMessageSource();
        bean.addBasenames("classpath:messages");
        return bean;
    }

    @Bean
    public CategoryServiceImp getCategoryServiceImp(){
        return new CategoryServiceImp();
    }

    @Bean
    public ProductServiceImp getProductServiceImp(){
        return  new ProductServiceImp();
    }

    @Bean
    public ProductDetailServiceImp getProductDetailServiceImp(){
        return new ProductDetailServiceImp();
    }
    @Bean
    public SizeServiceImp getSizeServiceImp(){
        return  new SizeServiceImp();
    }
    @Bean
    public ColorServiceImp getColorServiceImp(){
        return new ColorServiceImp();
    }
	    public NewsServiceImp getNewsServiceImp(){
        return new NewsServiceImp();
    }
}
