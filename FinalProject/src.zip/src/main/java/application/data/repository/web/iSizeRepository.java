package application.data.repository.web;

import application.data.model.Size;
import org.springframework.data.repository.CrudRepository;

public interface iSizeRepository extends CrudRepository<Size,Integer> {
}
