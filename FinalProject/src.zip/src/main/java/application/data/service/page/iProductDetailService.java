package application.data.service.page;

import application.data.model.ProductDetail;

public interface iProductDetailService {
    ProductDetail findOne(int productdetailid);
    void createDetail (ProductDetail productDetail);


}
