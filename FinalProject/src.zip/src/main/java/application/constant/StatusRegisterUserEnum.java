package application.constant;

public enum StatusRegisterUserEnum {
    Existed_Username,
    Existed_Email,
    Error_OnSystem,
    Success

}
