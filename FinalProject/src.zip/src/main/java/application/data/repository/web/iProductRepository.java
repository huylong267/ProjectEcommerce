package application.data.repository.web;

import application.data.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface iProductRepository extends JpaRepository<Product,Integer>{
}
