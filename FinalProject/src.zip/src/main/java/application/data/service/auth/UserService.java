package application.data.service.auth;

import application.data.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;



public interface UserService {

    List<User> findAll();

    User findOne(Integer id);

    long countAll();

    void delete(Integer id);


    boolean register(User user);

}